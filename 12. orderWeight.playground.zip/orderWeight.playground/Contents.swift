import Foundation


//https://www.codewars.com/kata/55c6126177c9441a570000cc

/*
 для начала для удобства работы получаем из строки массив весов weights
 получаем массив сумм цифр:
 для этого каждый элемент массива выше превращаем в строку, разбиваем на масиив строк, переводим это в массив
 цифр и складываем. Для иллюстрации - "56 65 74 100 99 68 86 180 90" -> "56" -> ["5", "6"] -> [5, 6] -> 0 + 5 + 6 = 11
 далее предстоит непростая задача - отсортировать массив sum, НО по порядку элементов массива weights
 для этого мы объединяем эти два массива в combined через метод zip, сортируем сначала по alphabetical ordering, потом по получившимся весам ( сумма цифр )
 в ответ выводим нужную часть combined (первую), попутно превращая массив чисел в строку через .joined(separator: " ")
 */

func orderWeight(_ s: String) -> String {
    let weights = s.split(separator: " ").map { String($0) }
    let sum: [Int] = weights.compactMap { $0.compactMap { Int(String($0)) }.reduce(0, +) }
    let combined = zip(weights, sum).sorted {$0.0 < $1.0}.sorted {$0.1 < $1.1}
    
    return combined.map { $0.0 }.joined(separator: " ")
}

