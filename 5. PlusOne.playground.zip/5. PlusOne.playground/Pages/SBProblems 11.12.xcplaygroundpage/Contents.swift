//: [Previous](@previous)

import Foundation


// 1

/*
 https://leetcode.com/problems/plus-one/
 
 You are given a large integer represented as an integer array digits, where each digits[i] is the ith digit of the integer. The digits are ordered from most significant to least significant in left-to-right order. The large integer does not contain any leading 0's.
 
 Increment the large integer by one and return the resulting array of digits.
 */

/*
Решение
Перевести изначальный массив в число, прибавить 1 и перевести обратно в массив было бы проще всего, но так
не получится тк в условиях не зря пишут, что число digits большое и оно может просто не влезть в Int.
Тогда нам придется пройтись циклом по массиву, сначала прибавив к последней цифре 1 и смотреть, если где то будет 10,
 то увеличивать следующие цифры.
 Для удобаства я в начало исходного массива ставлю дополнительный 0, на случай если число в итоге увеличится на порядок, а если нет - потом этот ноль убираю.
 Удобнее всего это делать с перевернутым массивом, поэтому я сначала переворачиваю исходный массив, прибавляю 1, а затем в ответе разворачиваю опять.
*/

func plusOne(_ digits: [Int]) -> [Int] {
    var dig = digits
    dig.insert(0, at: 0)
    dig.reverse()
    dig[0] += 1
    
    for i in 0 ..< dig.count {
        if dig[i] == 10 {
            dig[i] = 0
            dig[i + 1] += 1
        } else {
            break
        }
    }
    
    if dig.last! == 0 {
        dig.removeLast()
    }
    
    return dig.reversed()
}
