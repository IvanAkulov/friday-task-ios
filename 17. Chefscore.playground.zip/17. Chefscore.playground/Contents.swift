import Foundation



//https://www.codechef.com/problems/CHEFSCORE?tab=statement

/*
 Помним о комментариях в предыдущей задаче. Теперь в каждом тесте нужно получить сразу несколько нужных
 значений и они все приходят в одной строке. Получаем строку через readLine(), а дальше, для удобства,
 переводим в массив Int.
 
 Теперь доставая из массива нужные данные можно решить саму задачу, выводя в принт результат, в данном случае
 или "YES" или "NO"
 
 */

let numOfTests = Int(readLine()!)!

for _ in 1 ... numOfTests {
    let tempStr  = readLine()!.split(separator: " ").compactMap { Int(String($0)) }
    let problems = tempStr[0]
    let xMarks   = tempStr[1]
    let yMarks   = tempStr[2]

    if yMarks % xMarks == 0 && yMarks / xMarks <= problems {
        print("YES")
    } else {
        print("NO")
    }
}
