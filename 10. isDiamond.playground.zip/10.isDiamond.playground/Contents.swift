import UIKit

//https://www.codewars.com/kata/5503013e34137eeeaa001648

/*
 можно заметить, что относительно цетра наша фигура симметрична. те находя второй ряд, мы сразу находим предпоследний.
 Итак считаем центральную линию
 Далее циклом считаем последующие - меняем в начале строки * на пробел, и убираем лишнюю * в конце строки.
 Результат добавляем в ответ слева и справа 
 */

func diamond(_ size: Int) -> String? {
    guard !size.isMultiple(of: 2) && size > 0 else { return nil }
    
    if size == 1 { return "*\n" }
    
    
    var centerRow = Array(repeating: "*", count: size)
    centerRow.append("\n")
    var answer = centerRow
    
    for i in 1 ... size / 2 {
        centerRow[i - 1] = " "
        centerRow.remove(at: centerRow.count - 2)
        answer = centerRow + answer + centerRow
    }
    
    return answer.joined()
}
