import Foundation


//https://www.codechef.com/problems/ATM2

/*
 Помним о комментариях в предыдущей задаче. Получаем снала данные по количеству людей и объему денег.
 Далее получаем данные о запросах людей в выдаче.
 
 Циклом проходим по запросу денег и смотрим, может человек снять деньги или нет, не забывая уменьшать
 оставшиеся количество средсв.
 
 */

let numOfTests = Int(readLine()!)!

for _ in 1 ... numOfTests {
    let tempString = readLine()!.split(separator: " ").compactMap { Int(String($0)) }
    let totalPeople = tempString[0]
    var totalMoney = tempString[1]
    let turns = readLine()!.split(separator: " ").compactMap { Int(String($0)) }
    var answer = ""
    
    for element in turns {
        if totalMoney - element >= 0 {
            totalMoney -= element
            answer += "1"
        } else {
            answer += "0"
        }
    }
    
    print(answer)
}
