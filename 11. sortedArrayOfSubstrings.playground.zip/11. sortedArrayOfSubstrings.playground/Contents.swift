import Foundation

//https://www.codewars.com/kata/550554fd08b86f84fe000a58

/*
 Здесь первой задачей нужно понять что какая-то строка является чьей-то подстройкой в
 массиве. Для этого пишем вспомогательную функцию isSubstring(arr: [String], str: String) -> Bool.
 Далее, уже в основной фунции, мы можем использовать isSubstring как условие для фильтрации и дальнейшей сортировки.
 */

func inArray(_ a1: [String], _ a2: [String]) -> [String] {
    return Array(Set(a1.filter { isSubstring(arr: a2, str: $0) })).sorted(by: <)
}

func isSubstring(arr: [String], str: String) -> Bool {
    for element in arr {
        if element.contains(str) {
            return true
        }
    }
    return false
}
