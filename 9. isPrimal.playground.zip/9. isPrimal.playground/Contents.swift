import UIKit


//https://www.codewars.com/kata/5613d06cee1e7da6d5000055

/*
 Здесь самой затратной операцией является выяснение - это простое число или нет, поэтому я вынес в отдельный метод.
 Допустим мы берем число 101. нам нужно проверить все делилители. НО мы можем проверть делители до 51, тк выше уже точно не делитель, а если покопаться в теории то можем проверять делители и до корня из 101 - что еще больше нам облегчит поиск
 Так же мы можем из поиска убрать сразу все четные числа и в цикле for in тоже идти не подряд, а пропуская четные.
 Это все нужно оптимизировать тк вычислений будет много и без оптимизации наш алгоритм не пройдет по времени все тесты.
 
 а дальше в функции мы уже ищем два первыйх простых с требуемым промежутком.
 
 */

func step(_ g: Int, _ m: Int, _ n: Int) -> (Int, Int)? {
    var answer: (Int, Int)?

    for element in (m ... n) {
        if element.isMultiple(of: 2) {
            continue
        }
        if isPrimal(n: element) && isPrimal(n: (element + g)) && element + g <= n {
            answer = (element, element + g)
            break
        }
    }

    return answer
}

func isPrimal(n: Int) -> Bool {
    
    if n != 2 && n.isMultiple(of: 2) {
        return false
    }
    
    for x in stride(from: 3, to: Int(sqrt(Double(n))) + 1, by: 2) {
        if n.isMultiple(of: x) {
            return false
        }
    }
    
    return true
}
