import Foundation


//https://www.codechef.com/problems/EZSPEAK?tab=statement

/*
 Помним о комментариях в предыдущей задаче. В данном случае, нам приходят еще и не сильно нужные данные
 - количество букв в слове. Прочитать это нужно, использовать - нет, и если не прочитаем, то не сможем перейти
 к следующем вводу. Поэтому используем let _ = readLine().
 
 Дальше для удобства заменяем все гласные на "." - что бы потом удобно разбить на слога.
 word - массив слогов только из согласных. Дальше мы можем через filter посмотреть - есть ли там слоги с длиной > 3
 и, в зависимости от результата вывести ответ
 */

let vowels: [Character] = ["a", "e", "i", "o", "u"]
let numOfTests = Int(readLine()!)!

for _ in 1 ... numOfTests {
    let _ = readLine()
    let word = readLine()!.map { vowels.contains($0) ? "." : $0 }
                          .split(separator: ".")

    word.filter { $0.count > 3 }.count > 0 ? print("NO") : print("YES")
}


