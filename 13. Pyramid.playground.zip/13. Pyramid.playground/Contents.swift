import Foundation


/*
 Есть много способов решения, все более - менее одинаковые по смыслу - в цикле добавляем в массив ответа каждый раз возрастающий на 1 массив единичек. Ниже способ через for in 
 */

func pyramid(_ n: Int) -> [[Int]] {
    var answer = [[Int]]()
    
    for i in 0 ..< n {
        answer.append(Array(repeating: 1, count: (i + 1)))
    }
    
    return answer
}
