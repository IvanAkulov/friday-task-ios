import UIKit

// 1
//https://www.codewars.com/kata/54bf1c2cd5b56cc47f0007a1

/*
 На мой взгляд тут лучше всего использовать словарь. Для начала мы переводим все буквы в нижний регистр,
 тк по залданию у нас case-insensitive буквы.
 Далее с помощью метода .reduce(into: [:]) создаем словарь, в котором ключ - буква, а значегте - ее еколичество в слове
 с помощбю .filter получаем результаты по заданию - где больше 2х повторов и выводим ответ
 */

func countDuplicates(_ s:String) -> Int {
    return Array(s).map { $0.lowercased() }
                   .reduce(into: [:]) { s1Arr, char in s1Arr[char, default: 0] += 1 }
                   .filter { $1 > 1 }
                   .count
}

