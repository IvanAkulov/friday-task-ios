import UIKit


// 2
//https://www.codewars.com/kata/58f5c63f1e26ecda7e000029

/*
 Здесь нам нужно вывести массив со словами, где одна из букв будет в верхнем регистре
 для этого создаем пустой массив ответа
 итерируемся по изначальному слову и в каждой итерации делаем следующую букву заглавной через .uppercased()
 тк нам нужно вывести массив слов, а не массив массивов - переводим временный результат обратно в слово и добавляем в ответ
 
 */

func wave(_ y: String) -> [String] {
    var answer: [String] = []
    let word = y.map { String($0) }
    
    for i in 0 ..< word.count {
        if !Character(word[i]).isLetter {
            continue
        }
        var subWord = word
        subWord[i] = subWord[i].uppercased()
        answer.append(subWord.joined(separator: ""))
    }
    
    return answer
}

