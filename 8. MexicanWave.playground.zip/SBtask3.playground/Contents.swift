import UIKit

// 1
//https://www.codewars.com/kata/54bf1c2cd5b56cc47f0007a1

/*
 На мой взгляд тут лучше всего использовать словарь. Для начала мы переводим все буквы в нижний регистр,
 тк по залданию у нас case-insensitive буквы.
 Далее с помощью метода .reduce(into: [:]) создаем словарь, в котором ключ - буква, а значегте - ее еколичество в слове
 с помощбю .filter получаем результаты по заданию - где больше 2х повторов и выводим ответ
 */

func countDuplicates(_ s:String) -> Int {
    return Array(s).map { $0.lowercased() }
                   .reduce(into: [:]) { s1Arr, char in s1Arr[char, default: 0] += 1 }
                   .filter { $1 > 1 }
                   .count
}

// 2
//https://www.codewars.com/kata/58f5c63f1e26ecda7e000029

/*
 Здесь нам нужно вывести массив со словами, где одна из букв будет в верхнем регистре
 для этого создаем пустой массив ответа
 итерируемся по изначальному слову и в каждой итерации делаем следующую букву заглавной через .uppercased()
 тк нам нужно вывести массив слов, а не массив массивов - переводим временный результат обратно в слово и добавляем в ответ
 
 */

func wave(_ y: String) -> [String] {
    var answer: [String] = []
    let word = y.map { String($0) }
    
    for i in 0 ..< word.count {
        if !Character(word[i]).isLetter {
            continue
        }
        var subWord = word
        subWord[i] = subWord[i].uppercased()
        answer.append(subWord.joined(separator: ""))
    }
    
    return answer
}

// 3
//https://www.codewars.com/kata/5613d06cee1e7da6d5000055

/*
 Здесь самой затратной операцией является выяснение - это простое число или нет, поэтому я вынес в отдельный метод.
 Допустим мы берем число 101. нам нужно проверить все делилители. НО мы можем проверть делители до 51, тк выше уже точно не делитель, а если покопаться в теории то можем проверять делители и до корня из 101 - что еще больше нам облегчит поиск
 Так же мы можем из поиска убрать сразу все четные числа и в цикле for in тоже идти не подряд, а пропуская четные.
 Это все нужно оптимизировать тк вычислений будет много и без оптимизации наш алгоритм не пройдет по времени все тесты.
 
 а дальше в функции мы уже ищем два первыйх просытх с требуемым промежутком.
 
 */

func step(_ g: Int, _ m: Int, _ n: Int) -> (Int, Int)? {
    var answer: (Int, Int)?

    for element in (m ... n) {
        if element.isMultiple(of: 2) {
            continue
        }
        if isPrimal(n: element) && isPrimal(n: (element + g)) && element + g <= n {
            answer = (element, element + g)
            break
        }
    }

    return answer
}

func isPrimal(n: Int) -> Bool {
    
    if n != 2 && n.isMultiple(of: 2) {
        return false
    }
    
    for x in stride(from: 3, to: Int(sqrt(Double(n))) + 1, by: 2) {
        if n.isMultiple(of: x) {
            return false
        }
    }
    
    return true
}

//4
//https://www.codewars.com/kata/5503013e34137eeeaa001648

/*
 можно заметить, что относительно цетра наша фигура симметрична. те находя второй ряд, мы сразу находим предпоследний.
 Итак считаем центральную линию
 Далее циклом считаем последующие - меняем в начале строки * на пробел, и убираем лишнюю * в конце строки.
 Результат добавляем в ответ слева и справа 
 */

func diamond(_ size: Int) -> String? {
    guard !size.isMultiple(of: 2) && size > 0 else { return nil }
    
    if size == 1 { return "*\n" }
    
    
    var centerRow = Array(repeating: "*", count: size)
    centerRow.append("\n")
    var answer = centerRow
    
    for i in 1 ... size / 2 {
        centerRow[i - 1] = " "
        centerRow.remove(at: centerRow.count - 2)
        answer = centerRow + answer + centerRow
    }
    
    return answer.joined()
}
