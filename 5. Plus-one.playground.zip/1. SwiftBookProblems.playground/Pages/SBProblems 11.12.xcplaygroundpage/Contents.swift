//: [Previous](@previous)

import Foundation


// 1

/*
 https://leetcode.com/problems/plus-one/
 
 You are given a large integer represented as an integer array digits, where each digits[i] is the ith digit of the integer. The digits are ordered from most significant to least significant in left-to-right order. The large integer does not contain any leading 0's.
 
 Increment the large integer by one and return the resulting array of digits.
 */

/*
Решение
Перевести изначальный массив в число, прибавить 1 и перевести обратно в массив было бы проще всего, но так
не получится тк в условиях не зря пишут, что число digits большое и оно может просто не влезть в Int.
Тогда нам придется пройтись циклом по массиву, сначала прибавив к последней цифре 1 и смотреть, если где то будет 10,
 то увеличивать следующие цифры.
 Для удобаства я в начало исходного массива ставлю дополнительный 0, на случай если число в итоге увеличится на порядок, а если нет - потом этот ноль убираю.
 Удобнее всего это делать с перевернутым массивом, поэтому я сначала переворачиваю исходный массив, прибавляю 1, а затем в ответе разворачиваю опять.
*/

func plusOne(_ digits: [Int]) -> [Int] {
    var dig = digits
    dig.insert(0, at: 0)
    dig.reverse()
    dig[0] += 1
    
    for i in 0 ..< dig.count {
        if dig[i] == 10 {
            dig[i] = 0
            dig[i + 1] += 1
        } else {
            break
        }
    }
    
    if dig.last! == 0 {
        dig.removeLast()
    }
    
    return dig.reversed()
}

// 2

/*
 Given an integer columnNumber, return its corresponding column title as it appears in an Excel sheet.
 
 https://leetcode.com/problems/excel-sheet-column-title/
 */

/*
 Решение
 Можно заметить, что тут нам нужно привести нашу цифру в десятичной системе - в другую систему с базой 26.
 Далее каждую цифру привести к соответсвующей букве A...Z
 Для этого в while делим число на 26 и записываем остаток от деления.
 Что бы преобразовать цифру в букву - можно или сделать словарь из 26 букв-цифр или, что намного проще, посмотреть в таблицу юникод и заметить, что код "А" = 65. Те прибавляя 65 к цифре и преобразовав это через
 UnicodeScalar в String мы получим то, что нужно.
 
 */

func convertToTitle(_ columnNumber: Int) -> String {
    var result = ""
    var n = columnNumber
    
    while n > 0 {
        result = String(UnicodeScalar((n - 1) % 26 + 65)!) + result
        n = (n - 1) / 26
    }
    
    return result
}

convertToTitle(701)


// 3

/*
 Given two strings s and t, return true if t is an anagram of s, and false otherwise.
 
 An Anagram is a word or phrase formed by rearranging the letters of a different word or phrase, typically using all the original letters exactly once.
 
 https://leetcode.com/problems/valid-anagram/
 */

/*
 Решение. Что бы сравнить 2 строки по условию мы можем просто взять и сделать в них сортировку.
 Сравка Сфифта подсказывает нам, что sorted() имеет Complexity: O(n log n), что для больших - пребольших строк
 все же не очень.
 Способ сделать это за Complexity: O(n) - просто посчитать сколько штук каждой буквы в каждой строке и записать в словарь вида [Character : Int] - и сравнить уже эти 2 словаря. Тк каждый словарь будет заполняться за 1 проход, то мы и получим тут сложность O(n)
 
 */

func isAnagram(_ s: String, _ t: String) -> Bool {
    Array(s).sorted() == Array(t).sorted()
}

// 4

/*
 Решение
 Решений, как всегда, может быть много, но мне было интересно использовать тут редкую штуку makeIterator.
 Мы создаем итератор для нашей подстроки s и сразу идем на 1 букву.
 Далее, проходя циклом по строке t, если char в t соответствует текущему значению итератора, то итератор переходит на следующее, если нет - ничего не происходит и цикл продолжается.
 в конце концов мы проверяем положение итератора. если там nil - это значит, что итератор дошел до самого конца и условие выполнено, если там не nil - значит где то по дороге условия не были выполнены из-за отсутствия нужных букв или их другого порядка или еще чего, поэтому возвращаем false.
 */

/*
 Given two strings s and t, return true if s is a subsequence of t, or false otherwise.
 
 A subsequence of a string is a new string that is formed from the original string by deleting some (can be none) of the characters without disturbing the relative positions of the remaining characters. (i.e., "ace" is a subsequence of "abcde" while "aec" is not).
 
 
 https://leetcode.com/problems/is-subsequence/
 */



func isSubsequence(_ s: String, _ t: String) -> Bool {
    guard !s.isEmpty else { return true }
    var iterator = s.makeIterator()
    var currentChar: Character? = iterator.next()
    
    for char in t {
        if char == currentChar {
            currentChar = iterator.next()
        }
    }
    
    return currentChar == nil
}

isSubsequence("axc", "ahbgdc")
